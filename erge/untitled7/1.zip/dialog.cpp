#include "dialog.h"
#include "ui_dialog.h"
#include <QSerialPort>
#include <QSerialPortInfo>
#include <string>
#include <QDebug>
#include <QMessageBox>


Dialog::Dialog(QWidget *parent) :
    QDialog(parent)
{
    serial = new QSerialPort(this);
    serialBuffer = "";
    parsed_data = "";
    temperature_value = 0.0;
    qDebug() << "Number of ports: " << QSerialPortInfo::availablePorts().length() << "\n";
        foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
            qDebug() << "Description: " << serialPortInfo.description() << "\n";
            qDebug() << "Has vendor id?: " << serialPortInfo.hasVendorIdentifier() << "\n";
            qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier() << "\n";
            qDebug() << "Has product id?: " << serialPortInfo.hasProductIdentifier() << "\n";
            qDebug() << "Product ID: " << serialPortInfo.productIdentifier() << "\n";
      //  arduino_uno_product_id  =(quint16)serialPortInfo.productIdentifier();
        //arduino_uno_vendor_id  =(quint16)serialPortInfo.vendorIdentifier();
        }

    /*
     *  Testing code, prints the description, vendor id, and product id of all ports.
     *  Used it to determine the values for the arduino uno.
     *
     *
    qDebug() << "Number of ports: " << QSerialPortInfo::availablePorts().length() << "\n";
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
        qDebug() << "Description: " << serialPortInfo.description() << "\n";
        qDebug() << "Has vendor id?: " << serialPortInfo.hasVendorIdentifier() << "\n";
        qDebug() << "Vendor ID: " << serialPortInfo.vendorIdentifier() << "\n";
        qDebug() << "Has product id?: " << serialPortInfo.hasProductIdentifier() << "\n";
        qDebug() << "Product ID: " << serialPortInfo.productIdentifier() << "\n";
    }
    */


    /*
     *   Identify the port the arduino uno is on.
     */
    bool arduino_is_available = false;
    QString arduino_uno_port_name;
    //
    //  For each available serial port
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts()){
                //check if the serialport has both a product identifier and a vendor identifier
                if(serialPortInfo.hasProductIdentifier() && serialPortInfo.hasVendorIdentifier()){
                    //  check if the product ID and the vendor ID match those of the STM
                    if((arduino_uno_product_id == serialPortInfo.productIdentifier())
                            && (arduino_uno_vendor_id == serialPortInfo.vendorIdentifier())){
                        arduino_uno_port_name = serialPortInfo.portName();
                        break;
                    }
                }
            }

        serial = new QSerialPort(arduino_uno_port_name);
        qDebug() << QString(arduino_uno_port_name);

        if (!serial->open(QIODevice::ReadWrite))
            qDebug() << QString("failed to connect: failed to open port %1").arg(serial->errorString());

        if (!serial->setBaudRate(QSerialPort::Baud115200))
            qDebug() << QString("failed to connect: failed to setBaudRate(115200) %1").arg(serial->errorString());

        if (!serial->setStopBits(QSerialPort::OneStop))
            qDebug() << QString("failed to connect: failed to set QSerialPort::OneStop %1").arg(serial->errorString());

        if (!serial->setParity(QSerialPort::NoParity))
            qDebug() << QString("failed to connect: failed to set QSerialPort::NoParity %1").arg(serial->errorString());

        if (!serial->setDataBits(QSerialPort::Data8))
            qDebug() << QString("failed to connect: failed to set QSerialPort::Data8 %1").arg(serial->errorString());



        if (!serial->isOpen())
            qDebug() << QString("Device is not open!");
        else
            qDebug() << QString("Device is open!");

        return;

}

Dialog::~Dialog()
{
    if(serial->isOpen()){
        serial->close(); //    Close the serial port if it's open.
    }
    delete ui;
}

void Dialog::readSerial()
{
    /*
     * readyRead() doesn't guarantee that the entire message will be received all at once.
     * The message can arrive split into parts.  Need to buffer the serial data and then parse for the temperature value.
     *
     */

               if (serial->isOpen())
                    serial->close();
               printf("ads");
                serial->open(QIODevice::ReadWrite);
                 printf("ads");
                serial->write("b");

}

void Dialog::updateTemperature(QString sensor_reading)
{
    //  update the value displayed on the lcdNumber
    ui->temp_lcdNumber->display(sensor_reading);
}
