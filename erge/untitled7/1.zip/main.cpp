#include <QApplication>
#include "dialog.h"
#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("adsd");
    QApplication a(argc, argv);

    Dialog dd;
    printf("adsa");
    dd.readSerial();

    return a.exec();
}
