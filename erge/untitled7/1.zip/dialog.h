#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include <QSerialPort>
#include <QByteArray>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    void readSerial();

    ~Dialog();

private slots:
    void updateTemperature(QString);

private:
    Ui::Dialog *ui;

    QSerialPort *serial;
    static const quint16 arduino_uno_vendor_id = 1155;
    static const quint16 arduino_uno_product_id = 14155;
    QByteArray serialData;
    QString serialBuffer;
    QString parsed_data;
    double temperature_value;
};

#endif // DIALOG_H
